<!DOCTYPE html>
<html>
<body>
    <?php
    echo "1.Addition";
    echo "1.Substraction";
    echo "1.Multiplication";
    echo "1.Division";
    $c = readline("enter yourchoice here ");
    $x = 5;
    $y = 5;
    echo $c;
    // echo "The addition is " , $x + $y;
    // echo "<br>";
    // echo "The substraction is " , $x - $y;
    // echo "<br>";
    // echo "The multiplication is " , $x * $y;
    // echo "<br>"; 
    // echo "The division is " , $x / $y;
    
    ?>
</body>
</html>