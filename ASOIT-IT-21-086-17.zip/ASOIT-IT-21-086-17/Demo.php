<!DOCTYPE html>
<html>
<body>
    <?php
    echo "hello world";
    echo "<br>";
    $x = 5;
    $y = 4;
    $c = $x + $y;
    echo "The answer is $c.";
    ?>
</body>
</html>